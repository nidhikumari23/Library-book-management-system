const express = require("express");
const Book = require("../models/Book");
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");

const router = express.Router();

router.post("/", auth, role("admin"), async (req, res) => {
  const book = await Book.create(req.body);
  res.json(book);
});

router.get("/", auth, async (req, res) => {
  const books = await Book.find();
  res.json(books);
});

router.put("/:id", auth, role("admin"), async (req, res) => {
  const book = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(book);
});

router.delete("/:id", auth, role("admin"), async (req, res) => {
  await Book.findByIdAndDelete(req.params.id);
  res.json({ message: "Book deleted" });
});

module.exports = router;
