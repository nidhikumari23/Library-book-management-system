const express = require("express");
const Book = require("../models/Book");
const Borrow = require("../models/BorrowRecord");
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");

const router = express.Router();

router.post("/:bookId", auth, role("student"), async (req, res) => {
  const book = await Book.findById(req.params.bookId);
  if (book.availableCopies <= 0)
    return res.status(400).json({ message: "Not available" });

  book.availableCopies--;
  await book.save();

  const record = await Borrow.create({
    book: book._id,
    student: req.user.id
  });

  res.json(record);
});

router.patch("/return/:id", auth, role("student"), async (req, res) => {
  const record = await Borrow.findById(req.params.id);
  record.status = "returned";
  record.returnDate = new Date();
  await record.save();

  const book = await Book.findById(record.book);
  book.availableCopies++;
  await book.save();

  res.json({ message: "Returned" });
});

router.get("/history", auth, role("student"), async (req, res) => {
  const history = await Borrow.find({ student: req.user.id }).populate("book");
  res.json(history);
});

module.exports = router;
