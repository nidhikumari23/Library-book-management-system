const mongoose = require("mongoose");

const borrowSchema = new mongoose.Schema({
  book: { type: mongoose.Schema.Types.ObjectId, ref: "Book" },
  student: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  issuedAt: { type: Date, default: Date.now },
  returnDate: Date,
  status: { type: String, default: "borrowed" }
});

module.exports = mongoose.model("BorrowRecord", borrowSchema);
