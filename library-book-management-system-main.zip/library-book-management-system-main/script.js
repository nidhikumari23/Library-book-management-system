// --------------------------
// Index.html: Register/Login
// --------------------------
if (document.getElementById("registerForm")) {
    const token = localStorage.getItem("token");
    if(token) {
        const role = localStorage.getItem("role");
        window.location.href = role === "admin" ? "admin.html" : "student.html";
    }

    document.getElementById("registerForm").addEventListener("submit", async (e) => {
        e.preventDefault();
        const name = document.getElementById("regName").value;
        const email = document.getElementById("regEmail").value;
        const password = document.getElementById("regPassword").value;
        const role = document.getElementById("regRole").value;

        const res = await fetch("http://localhost:5000/api/auth/register", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({name, email, password, role})
        });
        const data = await res.json();
        alert(data.message || "Registered Successfully!");
        if(role === "admin") window.location.href = "admin.html";
        else window.location.href = "student.html";
    });

    document.getElementById("loginForm").addEventListener("submit", async (e) => {
        e.preventDefault();
        const email = document.getElementById("loginEmail").value;
        const password = document.getElementById("loginPassword").value;

        const res = await fetch("http://localhost:5000/api/auth/login", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({email, password})
        });
        const data = await res.json();
        if(data.token) {
            localStorage.setItem("token", data.token);
            localStorage.setItem("role", data.role);
            window.location.href = data.role === "admin" ? "admin.html" : "student.html";
        } else {
            alert(data.message || "Login Failed");
        }
    });
}

// --------------------------
// Logout Button (Student/Admin Pages)
// --------------------------
const logoutBtn = document.getElementById("logoutBtn");
if(logoutBtn) {
    logoutBtn.addEventListener("click", () => {
        localStorage.removeItem("token");
        localStorage.removeItem("role");
        window.location.href = "index.html";
    });
}



